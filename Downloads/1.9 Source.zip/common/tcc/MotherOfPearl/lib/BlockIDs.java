package tcc.MotherOfPearl.lib;

import darkevilmac.MotherOfPearl.Config.MOPConfiguration;

public class BlockIDs 
{
	/** BLOCK ID'S **/
	public static final int PearlFireID = MOPConfiguration.pearlFireID;
	public static final int PearlPortalID = MOPConfiguration.pearlPortalID;
}
