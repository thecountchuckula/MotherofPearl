package tcc.MotherOfPearl.lib;

import darkevilmac.MotherOfPearl.Config.MOPConfiguration;

public class ItemIDs 
{
	public static final int PearlFlintID = MOPConfiguration.pearlIgniterID;
	public static final int PearlPortalPlacerID = MOPConfiguration.pearlPortalPlacerID;
}
