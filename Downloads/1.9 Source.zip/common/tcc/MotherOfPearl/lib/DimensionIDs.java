package tcc.MotherOfPearl.lib;

public class DimensionIDs 
{
	/** Dimension ID's */
	public static int DIMID_1 = 2;
}
