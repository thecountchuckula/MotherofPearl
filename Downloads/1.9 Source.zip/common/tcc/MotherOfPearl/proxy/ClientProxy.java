package tcc.MotherOfPearl.proxy;

public class ClientProxy extends CommonProxy {

}
