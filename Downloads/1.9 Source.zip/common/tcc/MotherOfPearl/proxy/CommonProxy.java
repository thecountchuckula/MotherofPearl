package tcc.MotherOfPearl.proxy;

public class CommonProxy {

}
