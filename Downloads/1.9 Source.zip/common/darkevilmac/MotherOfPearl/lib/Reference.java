package darkevilmac.MotherOfPearl.lib;

public class Reference {

    public static final String NAME = "Mother of Pearl";
    public static final String MOD_ID = "mop";
    public static final String version = "v1.9-1.6.2";
    public static final String PROXY_PATH = "tcc.MotherOfPearl.proxy";

}
